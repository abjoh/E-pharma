import Epharma.*;

public class Start {
	public static void main(String[] args) {
		Admin a1 = new Admin();
		a1.setVisible(true);
	}
}