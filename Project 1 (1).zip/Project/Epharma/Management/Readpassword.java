package Epharma.Management;

import Epharma.*;

import java.io.*;
import java.lang.*;

public class Readpassword {
	private FileReader read;
    private BufferedReader buffer;
	
    
    public String addpassfile(String password){
		try {
			Filehandeling file = new Filehandeling();
			file.writeInFile(password,"Password.txt");
			}
		catch (NullPointerException e) {
			}
		return password;
		
	}
	public String[] readFromFile(String fname)
    {
		String[] password = null;
			try
			{
				File file = new File(fname);
				read = new FileReader(file);			//creating the reader object to read from a file.
				buffer = new BufferedReader(read);		//creating the BufferedReader object using the reader object to read the file content.
				String fullText="", singleLine;					//declaring two string variables to store the content after reading.
				
				int counter = 0;
	            while((singleLine=buffer.readLine())!=null){
	                counter++;
	            }
	            password = new String[counter];
	            int count=0;
	            
	            read = new FileReader(file);            //creating the reader object to read from a file.
	            buffer = new BufferedReader(read);  
	            
	            while(count<(counter-1))		//reading one line from the file, storing it in the variable temp and checking whether it is null or not. It will be null at the end of reading from the file.
	            {
	                singleLine=buffer.readLine();
	                password[count] = singleLine;
	               

	                
	                count++;
	                
	            }
				
				//System.out.println(fullText);				//printing the whole string in console.
				read.close();							//closing the file.
			}
			catch(IOException ioe)
			{
				ioe.printStackTrace();
			}
			return password;
        
    }
}
