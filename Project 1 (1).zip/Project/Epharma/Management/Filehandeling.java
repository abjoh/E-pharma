package Epharma.Management;

import Epharma.*;

import java.io.*;
import java.lang.*;

public class Filehandeling {
    private FileWriter write;
    
    public void writeInFile(String info, String fname)
    {
        try
        {
            File file = new File(fname);
            file.createNewFile();
            write = new FileWriter(file,false);
            write.write(info+"\r\n");
            write.flush();
            write.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }

    

}


