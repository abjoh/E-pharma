package Epharma.Customer;

import Epharma.Management.*;

public class Customer extends Person {
	protected double discount;

	public Customer(){
	}
	
	public Customer(String info, String name, String address, String phoneNumber, int age, double discount){
		super(info, name, address, phoneNumber, age);
		this.discount = discount;
		
	}
	
	public void setDiscount(double discount){
		this.discount = discount;
	}
	
	public double getDiscount(){
		return discount;
	}
	
	public String fileinfo(){
		String info =getInfo() +";"+ getName() +";"+ getAddress() +";"+ getPhoneNumber() +";"+ getAge() +";"+ getDiscount()+"\n";
		return info;
	}
	/*
	public void showDetailsOfCustomer(){
		super.showDetails();
		System.out.println("Discount : "+ getDiscount());
		
	}

	public static void main(String[] args){
		Customer c1 = new Customer("Customer", "Rahim", "Road #17, Nikunja - 2, Dhaka", "0174534****", 25, 0.07);
		
		c1.showDetailsOfCustomer();
		
		Customer c2 = new Customer();
		c2.setInfo("Customer");
		c2.setName("Karim");
		c2.setAddress("Road #17, Nikunja - 2, Dhaka");
		c2.setPhoneNumber("019*****8");
		c2.setAge(28);
		c2.setDiscount(0.07);
		c2.showDetailsOfCustomer();
	}
	*/
	
}