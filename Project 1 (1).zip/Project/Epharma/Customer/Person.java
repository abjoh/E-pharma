package Epharma.Customer;

public class Person {
	protected String info, name, address;
	protected String phoneNumber;
	protected int age;
	
	public Person(){
	}
	
	public Person(String info, String name, String address, String phoneNumber, int age){
		this.name = name;
		this.address = address;
		this.info = info;
		this.phoneNumber = phoneNumber;
		this.age = age;
	}
	
	public void setInfo(String info){
		this.info = info;
	}
	public String getInfo(){
		return info;
	}
	
	public void setName(String name){
		this.name = name;
	}
	public String getName(){
		return name;
	}
	
	public void setAddress(String address){
		this.address = address;
	}
	public String getAddress(){
		return address;
	}
	
	public void setPhoneNumber(String phoneNumber){
		this.phoneNumber = phoneNumber;
	}
	public String getPhoneNumber(){
		return phoneNumber;
	}
	
	public void setAge(int age){
		this.age = age;
	}
	public int getAge(){
		return age;
	}


	/*
public void showDetails(){
	System.out.println("Information of "+ getInfo()+" :");
	System.out.println("Name: "+ getName());
	System.out.println("Address: "+ getAddress());
	System.out.println("Phone Number: "+ getPhoneNumber());
	System.out.println("Age : "+ getAge());
}

public void ShowDetailsOfStaff(){
	System.out.println("Information of "+ getInfo()+" :");
	System.out.println("Name: "+ getName());
	System.out.println("Address: "+ getAddress());
	System.out.println("Phone Number: "+ getPhoneNumber());
	System.out.println("Age : "+ getAge());
}
*/
}