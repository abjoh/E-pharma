package Epharma.Customer;

import Epharma.Management.*;

public class AllCustomer1{
		protected Customer []listofcustomer;
	public AllCustomer1(){}
	public AllCustomer1(Customer []listofcustomer){
		this.listofcustomer = listofcustomer;
	}
	public void set_listofcustomer(Customer []listofcustomer){this.listofcustomer = listofcustomer;}

	public Customer[] get_listofcustomer(){return listofcustomer;}
	public void addcustomerfile(){
		String info="";
		
		for(Customer customer : listofcustomer){
			try {
			info= info +customer.fileinfo();
			Filehandeling file = new Filehandeling();
			file.writeInFile(info,"Customer.txt");
		}
		catch (NullPointerException e){
			continue;
		}
		}
		
	}
	public static Customer[] readcustomerfile(){
		Readcustomer file = new Readcustomer();
		return file.readFromFile("Customer.txt");

	}

	public Customer searchcustomerByName(String name){
		//below person does not work
		Customer searchcustomer = null;
		for(int i = 0;i<listofcustomer.length;i++){
			if (name.equals(listofcustomer[i].getName())){
				searchcustomer = listofcustomer[i];
			}
		}
		return searchcustomer;
	}

	public void addcustomer(Customer customer){
		for(int i = 0;i<listofcustomer.length;i++){
			if (listofcustomer[i] == null){
				listofcustomer[i] = customer;
				break;
			}
		}
	}

	public void deletecustomer(Customer customer){
		for(int i = 0;i<listofcustomer.length;i++){
			if (customer == listofcustomer[i]){
				listofcustomer[i] = null;
				break;
			}
		}
	}

	public void deletecustomerByName(String name){
		for(int i = 0;i<listofcustomer.length;i++){
			if (name.equalsIgnoreCase(listofcustomer[i].getName())){
				listofcustomer[i] = null;
				break;
			}
		}
	}
	/*
	public void showcustomerInfo(){
		for(Customer customer : listofcustomer){
			customer.showDetails();
		}
	}

	public static void main(String[] args) {
		Customer c1 = new Customer("Customer", "Rahim", "Road #17, Nikunja - 2, Dhaka", "0174534****", 25, 0.07);
		
		Customer c2 = new Customer();
		c2.setInfo("Customer");
		c2.setName("Karim");
		c2.setAddress("Road #17, Nikunja - 2, Dhaka");
		c2.setPhoneNumber("019*****8");
		c2.setAge(28);
		c2.setDiscount(0.07);

		Customer []customer ={c1,c2};

		AllCustomer1 customers = new AllCustomer1(customer);
		customers.addcustomerfile();
		customers.readcustomerfile();
	}*/
}

