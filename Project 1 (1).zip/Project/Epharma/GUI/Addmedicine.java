package Epharma.GUI;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.Medicine.*;
import Epharma.Customer.*;

import java.lang.NullPointerException;
import java.lang.NumberFormatException;

import java.awt.*;

import javax.swing.*;

import javax.swing.border.EmptyBorder;
import java.awt.Color;

import javax.swing.border.LineBorder;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Addmedicine extends JFrame {

	private JPanel contentPane;
	private JTextField medicinename;
	private JTextField genericname;
	private JTextField mgf;
	private JTextField exp;
	private JTextField suppliername;
	private JTextField address;
	private JTextField phone;
	private JTextField price;
	private JTextField quantity;


	public Addmedicine(Dashboard d1) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton Back = new JButton("Back");
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d1.setVisible(true);
				Addmedicine.this.setVisible(false);
			}
		});
		Back.setBounds(0, 0, 120, 35);
		contentPane.add(Back);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(102, 153, 51), 1, true));
		panel.setBackground(new Color(207, 235, 214));
		panel.setBounds(10, 50, 670, 600);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Medicine name");
		lblNewLabel.setBounds(10, 10, 100, 35);
		panel.add(lblNewLabel);
		
		medicinename = new JTextField();
		medicinename.setBounds(120, 10, 400, 35);
		panel.add(medicinename);
		medicinename.setColumns(10);
		
		JLabel lblChemicalName = new JLabel("Chemical name");
		lblChemicalName.setBounds(10, 55, 100, 35);
		panel.add(lblChemicalName);
		
		genericname = new JTextField();
		genericname.setBounds(120, 55, 400, 35);
		genericname.setColumns(10);
		panel.add(genericname);
		
		JLabel lblMfg = new JLabel("M.F.G.");
		lblMfg.setBounds(10, 100, 100, 35);
		panel.add(lblMfg);
		
		mgf = new JTextField();
		mgf.setBounds(120, 100, 400, 35);
		mgf.setColumns(10);
		panel.add(mgf);
		
		JLabel lblExp = new JLabel("Exp.");
		lblExp.setBounds(10, 145, 100, 35);
		panel.add(lblExp);
		
		exp = new JTextField();
		exp.setBounds(120, 145, 400, 35);
		exp.setColumns(10);
		panel.add(exp);
		
		JLabel lblCname = new JLabel("Company name");
		lblCname.setBounds(10, 190, 100, 35);
		panel.add(lblCname);
		
		suppliername = new JTextField();
		suppliername.setBounds(120, 190, 400, 35);
		suppliername.setColumns(10);
		panel.add(suppliername);
		
		JLabel lblCompanyAddress = new JLabel("Company address");
		lblCompanyAddress.setBounds(10, 235, 100, 35);
		panel.add(lblCompanyAddress);
		
		address = new JTextField();
		address.setBounds(120, 235, 400, 35);
		address.setColumns(10);
		panel.add(address);
		
		JLabel lblContactNo = new JLabel("Contact No.");
		lblContactNo.setBounds(10, 280, 100, 35);
		panel.add(lblContactNo);
		
		phone = new JTextField();
		phone.setBounds(120, 280, 400, 35);
		phone.setColumns(10);
		panel.add(phone);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setBounds(10, 326, 100, 35);
		panel.add(lblPrice);
		
		price = new JTextField();
		price.setBounds(120, 326, 400, 35);
		price.setColumns(10);
		panel.add(price);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setBounds(10, 372, 100, 35);
		panel.add(lblQuantity);
		
		quantity = new JTextField();
		quantity.setBounds(120, 372, 400, 35);
		quantity.setColumns(10);
		panel.add(quantity);
		
		JLabel lblNewLabel_2 = new JLabel("Inavlid input");
		lblNewLabel_2.setBounds(170, 450, 300, 23);
		lblNewLabel_2.setVisible(false);
		panel.add(lblNewLabel_2);
		
		
		JLabel lblNewLabel_1 = new JLabel("Already present");
		lblNewLabel_1.setBounds(170, 450, 300, 23);
		lblNewLabel_1.setVisible(false);
		panel.add(lblNewLabel_1);
		
		
		
		JButton btnNewButton_1 = new JButton("Add Medicine");
		btnNewButton_1.setBounds(260, 500, 150, 35);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String name = medicinename.getText();
					String chemical = genericname.getText();
					String manufacture = mgf.getText();
					String expire = exp.getText();
					String company = suppliername.getText();
					String add = address.getText();
					String num = phone.getText();
					double price1 = Double.parseDouble(price.getText());
					int quantity1 = Integer.parseInt(quantity.getText());
					int count = 0;
					Medicine[] meds = Allmeds.readfile();
					for(Medicine med:meds) {count++;}
					Medicine[] meds2 = new Medicine[count+1];
					for(int counter =0;counter<count;counter++) {meds2[counter]=meds[counter];}
					Allmeds a1 = new Allmeds(meds2);
					Allmeds a2 = new Allmeds(meds);
					Medicine medicine = a2.searchmedicineByName(name);
					try {
						medicine.get_medicinename();
						lblNewLabel_1.setVisible(true);
					}
					catch (NullPointerException e1) {
						a1.addmedicine(new Medicine(name, chemical, manufacture, expire, company, add, num, price1, quantity1));
						a1.addmedicinefile();
						d1.setVisible(true);
						Addmedicine.this.setVisible(false);
					}
				}
				catch (NumberFormatException e1) {
					lblNewLabel_2.setVisible(true);
					lblNewLabel_1.setVisible(false);
				}
				}
				
				
		});
		panel.add(btnNewButton_1);
		

	}
}
