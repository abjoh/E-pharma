package Epharma.GUI;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.Medicine.*;
import Epharma.Customer.*;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;


import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Allemployee extends JFrame {

	private JPanel contentPane;
	private JTable table;


	public Allemployee(Dashboard d1) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton Back = new JButton("Back");
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d1.setVisible(true);
				Allemployee.this.setVisible(false);
			}
		});
		Back.setBounds(0, 0, 120, 35);
		contentPane.add(Back);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new LineBorder(new Color(102, 153, 51), 1, true));
		panel.setBackground(new Color(207, 235, 214));
		panel.setBounds(10, 50, 670, 600);
		contentPane.add(panel);
		
		table = new JTable();
		AllStaff a1 = new AllStaff(AllStaff.readstafffile());
		AllCustomer1 c1 = new AllCustomer1(AllCustomer1.readcustomerfile());
		Customer[] c2 = c1.get_listofcustomer();
		Staff[] s1 = a1.get_listofstaff();
		
		Object[][] objs = new Object[s1.length+1][9];
		
		objs[0][0]="Type";
		objs[0][1]="Name";
		objs[0][2]="Address";
		objs[0][3]="Contact";
		objs[0][4]="Age";
		objs[0][5]="D.O.B";
		objs[0][6]="Designation";
		objs[0][7]="ID";
		objs[0][8]="Salary";
		
		for (int i=1;i<=(s1.length);i++) {
			objs[i][0]=s1[i-1].getInfo();
			objs[i][1]=s1[i-1].getName();
			objs[i][2]=s1[i-1].getAddress();
			objs[i][3]=s1[i-1].getPhoneNumber();
			objs[i][4]=s1[i-1].getAge();
			objs[i][5]=s1[i-1].getDob();
			objs[i][6]=s1[i-1].getDesignation();
			objs[i][7]=s1[i-1].getId();
			objs[i][8]=s1[i-1].getSalary();
			
		}
		
		
		table.setModel(new DefaultTableModel(objs,
			new String[] {
					"Type", "Name", "Address", "Contact", "Age", "D.O.B","Designation","ID","Salary"
			}
		));
		table.setBounds(10, 50, 650, 540);
		panel.add(table);
		
		JLabel lblNewLabel = new JLabel("List of employees");
		lblNewLabel.setBounds(10, 10, 121, 32);
		panel.add(lblNewLabel);
	}
}
