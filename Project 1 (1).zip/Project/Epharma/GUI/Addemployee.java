package Epharma.GUI;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.Medicine.*;
import Epharma.Customer.*;

import java.lang.NumberFormatException;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Addemployee extends JFrame {

	private JPanel contentPane;
	private JTextField name;
	private JTextField address;
	private JTextField contact;
	private JTextField age;
	private JTextField dob;
	private JTextField designation;
	private JTextField ID;
	private JTextField salary;


	public Addemployee(Dashboard d1) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton Back = new JButton("Back");
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d1.setVisible(true);
				Addemployee.this.setVisible(false);
			}
		});
		Back.setBounds(0, 0, 120, 35);
		contentPane.add(Back);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(102, 153, 51), 1, true));
		panel.setBackground(new Color(207, 235, 214));
		panel.setBounds(10, 50, 670, 600);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Employee name");
		lblNewLabel.setBounds(10, 10, 100, 35);
		panel.add(lblNewLabel);
		
		name = new JTextField();
		name.setBounds(120, 10, 400, 35);
		panel.add(name);
		name.setColumns(10);
		
		JLabel lblChemicalName = new JLabel("Address");
		lblChemicalName.setBounds(10, 55, 100, 35);
		panel.add(lblChemicalName);
		
		address = new JTextField();
		address.setColumns(10);
		address.setBounds(120, 55, 400, 35);
		panel.add(address);
		
		JLabel lblMfg = new JLabel("Contact No.");
		lblMfg.setBounds(10, 100, 100, 35);
		panel.add(lblMfg);
		
		contact = new JTextField();
		contact.setColumns(10);
		contact.setBounds(120, 100, 400, 35);
		panel.add(contact);
		
		JLabel lblExp = new JLabel("Age");
		lblExp.setBounds(10, 145, 100, 35);
		panel.add(lblExp);
		
		age = new JTextField();
		age.setColumns(10);
		age.setBounds(120, 145, 400, 35);
		panel.add(age);
		
		JLabel lblCname = new JLabel("Date of Birth");
		lblCname.setBounds(10, 190, 100, 35);
		panel.add(lblCname);
		
		dob = new JTextField();
		dob.setColumns(10);
		dob.setBounds(120, 190, 400, 35);
		panel.add(dob);
		
		JLabel lblCompanyAddress = new JLabel("Designation");
		lblCompanyAddress.setBounds(10, 235, 100, 35);
		panel.add(lblCompanyAddress);
		
		designation = new JTextField();
		designation.setColumns(10);
		designation.setBounds(120, 235, 400, 35);
		panel.add(designation);
		
		JLabel lblContactNo = new JLabel("ID");
		lblContactNo.setBounds(10, 280, 100, 35);
		panel.add(lblContactNo);
		
		ID = new JTextField();
		ID.setColumns(10);
		ID.setBounds(120, 280, 400, 35);
		panel.add(ID);
		
		JLabel lblNewLabel_1 = new JLabel("Wrong input");
		lblNewLabel_1.setBounds(270, 400, 150, 20);
		lblNewLabel_1.setVisible(false);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Already Exist");
		lblNewLabel_2.setBounds(270, 400, 150, 20);
		lblNewLabel_2.setVisible(false);
		panel.add(lblNewLabel_2);
		
		JButton addemployee = new JButton("Add Employee");
		addemployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				String info = "employee";
				String name1 = name.getText();
				String address1 = address.getText();
				String phoneNumber = contact.getText();
				int age1 = Integer.parseInt(age.getText());
				String dob1 = dob.getText();
				String designation1 = designation.getText();
				String id = ID.getText();
				int salary1 = Integer.parseInt(salary.getText());
				
				int count = 0;
				Staff[] staffs = AllStaff.readstafffile();
				for(Staff staff:staffs) {count++;}
				Staff[] staffs2 = new Staff[count+1];
				for(int counter =0;counter<count;counter++) {staffs2[counter]=staffs[counter];}
				AllStaff a1 = new AllStaff(staffs2);
				AllStaff a2 = new AllStaff(staffs);
				Staff staff = a2.searchstaffByName(name1);
				try {
					staff.getName();
					lblNewLabel_2.setVisible(true);
				}
				catch (NullPointerException e1) {
					a1.addstaff(new Staff(info,name1,address1,phoneNumber,age1,dob1,designation1,id,salary1));
					a1.addstafffile();
					d1.setVisible(true);
					Addemployee.this.setVisible(false);
				}
				}
				catch (NumberFormatException e2) {
					lblNewLabel_1.setVisible(true);
				}
			}
		});
		addemployee.setBounds(260, 450, 150, 35);
		panel.add(addemployee);
		
		JLabel lblContactNo_1 = new JLabel("Salary");
		lblContactNo_1.setBounds(10, 325, 100, 35);
		panel.add(lblContactNo_1);
		
		salary = new JTextField();
		salary.setColumns(10);
		salary.setBounds(120, 325, 400, 35);
		panel.add(salary);
		
		
		
		
	}
}
