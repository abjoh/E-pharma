package Epharma.GUI;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.Medicine.*;
import Epharma.Customer.*;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;


public class AllMedicine extends JFrame {

	private JPanel contentPane;
	private JTable table;


	public AllMedicine(Dashboard d1) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton Back = new JButton("Back");
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d1.setVisible(true);
				AllMedicine.this.setVisible(false);
			}
		});
		Back.setBounds(0, 0, 120, 35);
		contentPane.add(Back);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new LineBorder(new Color(102, 153, 51), 1, true));
		panel.setBackground(new Color(207, 235, 214));
		panel.setBounds(10, 50, 670, 600);
		contentPane.add(panel);
		
		table = new JTable();
		Allmeds a1 = new Allmeds(Allmeds.readfile());
		Medicine[] m1 = a1.get_listofmeds();
		Object[][] objs = new Object[m1.length+1][9];
		
		objs[0][0]="Name";
		objs[0][1]="Chemical";
		objs[0][2]="M.F.G";
		objs[0][3]="Exp.";
		objs[0][4]="Comapny";
		objs[0][5]="Address";
		objs[0][6]="Contact";
		objs[0][7]="Price";
		objs[0][8]="Quantity";
		
		for (int i=1;i<=(m1.length);i++) {
			objs[i][0]=m1[i-1].get_medicinename();
			objs[i][1]=m1[i-1].get_genericname();
			objs[i][2]=m1[i-1].get_mgf();
			objs[i][3]=m1[i-1].get_exp();
			objs[i][4]=m1[i-1].get_Name();
			objs[i][5]=m1[i-1].get_Address();
			objs[i][6]=m1[i-1].get_Phone();
			objs[i][7]=m1[i-1].getPrice();
			objs[i][8]=m1[i-1].getQuantity();
			
			
		}
		table.setModel(new DefaultTableModel(objs,
			new String[] {
				"Name", "Chemical", "M.F.G", "Exp.", "Company", "Address","Contact", "Price", "Quantity"
			}
		));
		table.setBounds(10, 50, 650, 540);
		panel.add(table);
		
		JLabel lblNewLabel = new JLabel("List of medicines");
		lblNewLabel.setBounds(10, 10, 121, 32);
		panel.add(lblNewLabel);
	}

}
