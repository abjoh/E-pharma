package Epharma.GUI;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.Medicine.*;
import Epharma.Customer.*;


//import Source.*;
import java.awt.*;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class Dashboard extends JFrame {

	private JPanel contentPane;


	public Dashboard() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(15, 82, 87));
		panel.setBounds(0, 0, 210, 660);
		contentPane.add(panel);
		
		JButton addmedicine = new JButton("Add medicine");
		addmedicine.setBounds(0, 0, 200, 50);
		addmedicine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Addmedicine am = new Addmedicine(Dashboard.this);
				am.setVisible(true);
				
			}
		});
		panel.setLayout(null);
		panel.add(addmedicine);
		
		JButton addemployee = new JButton("Add Employee");
		addemployee.setBounds(0, 60, 200, 50);
		panel.add(addemployee);
		addemployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Addemployee aem = new Addemployee(Dashboard.this);
				aem.setVisible(true);
				
			}
		});
		
		JButton addcustomer = new JButton("Add Customer");
		addcustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddCustomer ac = new AddCustomer(Dashboard.this);
				ac.setVisible(true);
			}
		});
		addcustomer.setBounds(0, 120, 200, 50);
		panel.add(addcustomer);
		
		JButton changemed = new JButton("Change medicine info");
		changemed.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Changemedicine cm = new Changemedicine(Dashboard.this);
				cm.setVisible(true);
			}
		});
		changemed.setBounds(0, 180, 200, 50);
		panel.add(changemed);
		
		
		JButton changeemployee = new JButton("Change employee info");
		changeemployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Changeemployee ce = new Changeemployee(Dashboard.this);
				ce.setVisible(true);
			}
		});
		changeemployee.setBounds(0, 240, 200, 50);
		panel.add(changeemployee);
		
		
		JButton Receit = new JButton("Receit");
		Receit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Receit re = new Receit(Dashboard.this);
				re.setVisible(true);
			}
		});
		Receit.setBounds(0, 300, 200, 50);
		panel.add(Receit);
		
		JButton btnRemoveEmployee = new JButton("Remove employee");
		btnRemoveEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Deleteemployee de = new Deleteemployee(Dashboard.this);
				de.setVisible(true);
			}
		});
		btnRemoveEmployee.setBounds(0, 361, 200, 50);
		panel.add(btnRemoveEmployee);
		
		JButton btnRemoveMedicine = new JButton("Remove medicine");
		btnRemoveMedicine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Deletemedicine dm = new Deletemedicine(Dashboard.this);
				dm.setVisible(true);
			}
		});
		btnRemoveMedicine.setBounds(0, 422, 200, 50);
		panel.add(btnRemoveMedicine);
		
		JButton btnRemoveCustomer = new JButton("Remove customer");
		btnRemoveCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Deletecustomer dc = new Deletecustomer(Dashboard.this);
				dc.setVisible(true);
			}
		});
		btnRemoveCustomer.setBounds(0, 483, 200, 50);
		panel.add(btnRemoveCustomer);
		
		JButton btnRemoveMedicine_1_1 = new JButton("Change password");
		btnRemoveMedicine_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Changepassword cp = new Changepassword(Dashboard.this);
				cp.setVisible(true);

			}
		});
		btnRemoveMedicine_1_1.setBounds(0, 544, 200, 50);
		panel.add(btnRemoveMedicine_1_1);
		
		
		
		
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(207, 235, 214));
		panel_1.setBounds(220, 0, 460, 660);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		AllStaff as1 = new AllStaff(AllStaff.readstafffile());
		Staff[] s1=as1.get_listofstaff();
		Allmeds am1 = new Allmeds(Allmeds.readfile());
		Medicine[] m1 = am1.get_listofmeds();
		AllCustomer1 ac1 =new AllCustomer1(AllCustomer1.readcustomerfile());
		Customer[] c1=ac1.get_listofcustomer();
		JLabel lblNewLabel = new JLabel("Welcome user.");
		lblNewLabel.setBorder(new LineBorder(new Color(136, 174, 111), 1, true));
		lblNewLabel.setBounds(0, 0, 460, 130);
		panel_1.add(lblNewLabel);
		
		JButton Employee = new JButton("Employee");
		Employee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Allemployee alle = new Allemployee(Dashboard.this);
				alle.setVisible(true);
			}
		});
		Employee.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		Employee.setVerticalAlignment(SwingConstants.BOTTOM);
		Employee.setBounds(10, 160, 200, 200);
		panel_1.add(Employee);
		
		
		JButton Medicine = new JButton("Medicine");
		Medicine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AllMedicine allm = new AllMedicine(Dashboard.this);
				allm.setVisible(true);
			}
		});
		Medicine.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		Medicine.setVerticalAlignment(SwingConstants.BOTTOM);
		Medicine.setBounds(250, 160, 200, 200);
		panel_1.add(Medicine);
		
		JButton Customer = new JButton("Customer");
		Customer.setVerticalAlignment(SwingConstants.BOTTOM);
		Customer.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		Customer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AllCustomer allc = new AllCustomer(Dashboard.this);
				allc.setVisible(true);
			}
		});
		Customer.setBounds(105, 370, 200, 200);
		panel_1.add(Customer);
		
		
		
	}
}
