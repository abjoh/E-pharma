package Epharma.GUI;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.Medicine.*;
import Epharma.Customer.*;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AllCustomer extends JFrame {

	private JPanel contentPane;
	private JTable table;


	public AllCustomer(Dashboard d1) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton Back = new JButton("Back");
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d1.setVisible(true);
				AllCustomer.this.setVisible(false);
			}
		});
		Back.setBounds(0, 0, 120, 35);
		contentPane.add(Back);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new LineBorder(new Color(102, 153, 51), 1, true));
		panel.setBackground(new Color(207, 235, 214));
		panel.setBounds(10, 50, 670, 600);
		contentPane.add(panel);
		
		table = new JTable();
		AllCustomer1 c1 = new AllCustomer1(AllCustomer1.readcustomerfile());
		Customer[] c2 = c1.get_listofcustomer();
		
		Object[][] objs = new Object[c2.length+1][6];
		
		objs[0][0]="Type";
		objs[0][1]="Name";
		objs[0][2]="Address";
		objs[0][3]="Contact";
		objs[0][4]="Age";
		objs[0][5]="Discount";
		
		
		for (int i=1;i<=(c2.length);i++) {
			objs[i][0]=c2[i-1].getInfo();
			objs[i][1]=c2[i-1].getName();
			objs[i][2]=c2[i-1].getAddress();
			objs[i][3]=c2[i-1].getPhoneNumber();
			objs[i][4]=c2[i-1].getAge();
			objs[i][5]=c2[i-1].getDiscount();
			
		}
		
		
		table.setModel(new DefaultTableModel(objs,
			new String[] {
					"Type", "Name", "Address", "Contact", "Age", "Discount"
			}
		));
		table.setBounds(10, 50, 650, 540);
		panel.add(table);
		
		JLabel lblNewLabel = new JLabel("List of customers");
		lblNewLabel.setBounds(10, 10, 121, 32);
		panel.add(lblNewLabel);
	}

}
