package Epharma.GUI;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.Medicine.*;
import Epharma.Customer.*;

import java.lang.NullPointerException;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Changemedicine extends JFrame {

	private JPanel contentPane;
	private JTextField name1;


	public Changemedicine(Dashboard d1) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton Back = new JButton("Back");
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d1.setVisible(true);
				Changemedicine.this.setVisible(false);
			}
		});
		Back.setBounds(0, 0, 120, 35);
		contentPane.add(Back);
		
		name1 = new JTextField();
		name1.setBounds(260, 200, 300, 35);
		contentPane.add(name1);
		name1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Not found");
		lblNewLabel_1.setBounds(350, 370, 150, 30);
		lblNewLabel_1.setVisible(false);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_1 = new JButton("Search");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = name1.getText();
				Allmeds a1 = new Allmeds(Allmeds.readfile());
				Medicine search = a1.searchmedicineByName(name);
				try {
					search.get_medicinename();
					Modifymed m1 = new Modifymed(Changemedicine.this,search);
					m1.setVisible(true);
					Changemedicine.this.setVisible(false);
					
					
				}
				catch (NullPointerException e1) {
					lblNewLabel_1.setVisible(true);
				}
			}
		});
		btnNewButton_1.setBounds(300, 280, 100, 30);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("Medicine Name");
		lblNewLabel.setBounds(150, 200, 100, 35);
		contentPane.add(lblNewLabel);
		

	}
}
