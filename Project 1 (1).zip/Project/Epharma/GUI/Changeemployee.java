package Epharma.GUI;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.Medicine.*;
import Epharma.Customer.*;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Changeemployee extends JFrame {

	private JPanel contentPane;
	private JTextField name;


	public Changeemployee(Dashboard d1) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton Back = new JButton("Back");
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d1.setVisible(true);
				Changeemployee.this.setVisible(false);
			}
		});
		Back.setBounds(0, 0, 120, 35);
		contentPane.add(Back);
		
		JLabel lblEmployeeName = new JLabel("Employee Name");
		lblEmployeeName.setBounds(130, 200, 100, 35);
		contentPane.add(lblEmployeeName);
		
		name = new JTextField();
		name.setColumns(10);
		name.setBounds(240, 200, 300, 35);
		contentPane.add(name);
		
		JButton btnNewButton_1 = new JButton("Search");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name1 = name.getText();
				AllStaff a1 = new AllStaff(AllStaff.readstafffile());
				Staff search = a1.searchstaffByName(name1);
				try {
					search.getName();
					Modifyemployee m1 = new Modifyemployee(Changeemployee.this,search);
					m1.setVisible(true);
					Changeemployee.this.setVisible(false);
					
					
				}
				catch (NullPointerException e1) {
				
				}
				}
		});
		btnNewButton_1.setBounds(280, 280, 100, 30);
		contentPane.add(btnNewButton_1);
	}
}


