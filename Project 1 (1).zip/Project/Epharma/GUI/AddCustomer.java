package Epharma.GUI;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.Medicine.*;
import Epharma.Customer.*;

import java.lang.NumberFormatException;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddCustomer extends JFrame {

	private JPanel contentPane;
	private JTextField name;
	private JTextField address;
	private JTextField contact;
	private JTextField age;


	public AddCustomer(Dashboard d1) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton Back = new JButton("Back");
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d1.setVisible(true);
				AddCustomer.this.setVisible(false);
			}
		});
		Back.setBounds(0, 0, 120, 35);
		contentPane.add(Back);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(102, 153, 51), 1, true));
		panel.setBackground(new Color(207, 235, 214));
		panel.setBounds(10, 50, 670, 600);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Customer name");
		lblNewLabel.setBounds(10, 10, 100, 35);
		panel.add(lblNewLabel);
		
		name = new JTextField();
		name.setBounds(120, 10, 400, 35);
		panel.add(name);
		name.setColumns(10);
		
		JLabel lblChemicalName = new JLabel("Address");
		lblChemicalName.setBounds(10, 55, 100, 35);
		panel.add(lblChemicalName);
		
		address = new JTextField();
		address.setBounds(120, 55, 400, 35);
		address.setColumns(10);
		panel.add(address);
		
		JLabel lblMfg = new JLabel("Contact No.");
		lblMfg.setBounds(10, 100, 100, 35);
		panel.add(lblMfg);
		
		contact = new JTextField();
		contact.setBounds(120, 100, 400, 35);
		contact.setColumns(10);
		panel.add(contact);
		
		JLabel lblExp = new JLabel("Age");
		lblExp.setBounds(10, 145, 100, 35);
		panel.add(lblExp);
		
		age = new JTextField();
		age.setBounds(120, 145, 400, 35);
		age.setColumns(10);
		panel.add(age);
		
		JLabel lblNewLabel_1 = new JLabel("Invalid Input");
		lblNewLabel_1.setBounds(270, 250, 150, 20);
		lblNewLabel_1.setVisible(false);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Already exist");
		lblNewLabel_2.setBounds(270, 250, 150, 20);
		lblNewLabel_2.setVisible(false);
		panel.add(lblNewLabel_2);
		
		JButton btnNewButton_1 = new JButton("Add Customer");
		btnNewButton_1.setBounds(260, 300, 150, 35);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String info = "customer";
					String name1 = name.getText();
					String address1 = address.getText();
					String phoneNumber = contact.getText();
					int age1 = Integer.parseInt(age.getText());
					double discount1 = 0.07;
					

					
					int count = 0;
					Customer[] customers = AllCustomer1.readcustomerfile();
					for(Customer customer:customers) {count++;}
					Customer[] customers2 = new Customer[count+1];
					for(int counter =0;counter<count;counter++) {customers2[counter]=customers[counter];}
					AllCustomer1 a1 = new AllCustomer1(customers2);
					AllCustomer1 a2 = new AllCustomer1(customers);
					Customer customer = a2.searchcustomerByName(name1);
					try {
						customer.getName();
						lblNewLabel_2.setVisible(true);
					}
					catch (NullPointerException e1) {
						a1.addcustomer(new Customer(info,name1,address1,phoneNumber,age1,discount1));
						a1.addcustomerfile();
						d1.setVisible(true);
						AddCustomer.this.setVisible(false);
					}
					}
					catch (NumberFormatException e2) {
						lblNewLabel_1.setVisible(true);
					}
			}
		});
		panel.add(btnNewButton_1);
		
		
	}

}
