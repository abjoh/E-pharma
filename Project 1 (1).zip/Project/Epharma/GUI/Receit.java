package Epharma.GUI;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.Medicine.*;
import Epharma.Customer.*;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Receit extends JFrame {

	private JPanel contentPane;
	private JTextField name1;
	private JTextField quantity1;
	private JTextField name2;
	private JTextField quantity2;
	private JTextField name3;
	private JTextField quantity3;
	private JTextField name4;
	private JTextField quantity4;
	private JTextField name5;
	private JTextField quantity5;
	private JTextField name6;
	private JTextField quantity6;
	private JTextField name7;
	private JTextField quantity7;
	private JTextField name8;
	private JTextField quantity8;
	private JTextField name9;
	private JTextField quantity9;
	private JTextField name10;
	private JTextField quantity10;
	private JTextField customer;


	public Receit(Dashboard d1) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton Back = new JButton("Back");
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d1.setVisible(true);
				Receit.this.setVisible(false);
			}
		});
		Back.setBounds(0, 0, 120, 35);
		contentPane.add(Back);
		
		JLabel lblNewLabel = new JLabel("Medicine name");
		lblNewLabel.setBounds(20, 80, 100, 25);
		contentPane.add(lblNewLabel);
		
		name1 = new JTextField();
		name1.setBounds(160, 80, 200, 25);
		contentPane.add(name1);
		name1.setColumns(10);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setBounds(370, 80, 80, 25);
		contentPane.add(lblQuantity);
		
		quantity1 = new JTextField();
		quantity1.setColumns(10);
		quantity1.setBounds(450, 80, 200, 25);
		contentPane.add(quantity1);
		
		JLabel lblNewLabel_1 = new JLabel("Medicine name");
		lblNewLabel_1.setBounds(20, 116, 100, 25);
		contentPane.add(lblNewLabel_1);
		
		name2 = new JTextField();
		name2.setColumns(10);
		name2.setBounds(160, 116, 200, 25);
		contentPane.add(name2);
		
		JLabel lblQuantity_1 = new JLabel("Quantity");
		lblQuantity_1.setBounds(370, 116, 80, 25);
		contentPane.add(lblQuantity_1);
		
		quantity2 = new JTextField();
		quantity2.setColumns(10);
		quantity2.setBounds(450, 116, 200, 25);
		contentPane.add(quantity2);
		
		JLabel lblNewLabel_2 = new JLabel("Medicine name");
		lblNewLabel_2.setBounds(20, 152, 100, 25);
		contentPane.add(lblNewLabel_2);
		
		name3 = new JTextField();
		name3.setColumns(10);
		name3.setBounds(160, 152, 200, 25);
		contentPane.add(name3);
		
		JLabel lblQuantity_2 = new JLabel("Quantity");
		lblQuantity_2.setBounds(370, 152, 80, 25);
		contentPane.add(lblQuantity_2);
		
		quantity3 = new JTextField();
		quantity3.setColumns(10);
		quantity3.setBounds(450, 152, 200, 25);
		contentPane.add(quantity3);
		
		JLabel lblNewLabel_3 = new JLabel("Medicine name");
		lblNewLabel_3.setBounds(20, 188, 100, 25);
		contentPane.add(lblNewLabel_3);
		
		name4 = new JTextField();
		name4.setColumns(10);
		name4.setBounds(160, 188, 200, 25);
		contentPane.add(name4);
		
		JLabel lblQuantity_3 = new JLabel("Quantity");
		lblQuantity_3.setBounds(370, 188, 80, 25);
		contentPane.add(lblQuantity_3);
		
		quantity4 = new JTextField();
		quantity4.setColumns(10);
		quantity4.setBounds(450, 188, 200, 25);
		contentPane.add(quantity4);
		
		JLabel lblNewLabel_4 = new JLabel("Medicine name");
		lblNewLabel_4.setBounds(20, 224, 100, 25);
		contentPane.add(lblNewLabel_4);
		
		name5 = new JTextField();
		name5.setColumns(10);
		name5.setBounds(160, 224, 200, 25);
		contentPane.add(name5);
		
		JLabel lblQuantity_4 = new JLabel("Quantity");
		lblQuantity_4.setBounds(370, 224, 80, 25);
		contentPane.add(lblQuantity_4);
		
		quantity5 = new JTextField();
		quantity5.setColumns(10);
		quantity5.setBounds(450, 224, 200, 25);
		contentPane.add(quantity5);
		
		JLabel lblNewLabel_5 = new JLabel("Medicine name");
		lblNewLabel_5.setBounds(20, 260, 100, 25);
		contentPane.add(lblNewLabel_5);
		
		name6 = new JTextField();
		name6.setColumns(10);
		name6.setBounds(160, 260, 200, 25);
		contentPane.add(name6);
		
		JLabel lblQuantity_5 = new JLabel("Quantity");
		lblQuantity_5.setBounds(370, 260, 80, 25);
		contentPane.add(lblQuantity_5);
		
		quantity6 = new JTextField();
		quantity6.setColumns(10);
		quantity6.setBounds(450, 260, 200, 25);
		contentPane.add(quantity6);
		
		JLabel lblNewLabel_6 = new JLabel("Medicine name");
		lblNewLabel_6.setBounds(20, 296, 100, 25);
		contentPane.add(lblNewLabel_6);
		
		name7 = new JTextField();
		name7.setColumns(10);
		name7.setBounds(160, 296, 200, 25);
		contentPane.add(name7);
		
		JLabel lblQuantity_6 = new JLabel("Quantity");
		lblQuantity_6.setBounds(370, 296, 80, 25);
		contentPane.add(lblQuantity_6);
		
		quantity7 = new JTextField();
		quantity7.setColumns(10);
		quantity7.setBounds(450, 296, 200, 25);
		contentPane.add(quantity7);
		
		JLabel lblNewLabel_7 = new JLabel("Medicine name");
		lblNewLabel_7.setBounds(20, 332, 100, 25);
		contentPane.add(lblNewLabel_7);
		
		name8 = new JTextField();
		name8.setColumns(10);
		name8.setBounds(160, 332, 200, 25);
		contentPane.add(name8);
		
		JLabel lblQuantity_7 = new JLabel("Quantity");
		lblQuantity_7.setBounds(370, 332, 80, 25);
		contentPane.add(lblQuantity_7);
		
		quantity8 = new JTextField();
		quantity8.setColumns(10);
		quantity8.setBounds(450, 332, 200, 25);
		contentPane.add(quantity8);
		
		JLabel lblNewLabel_8 = new JLabel("Medicine name");
		lblNewLabel_8.setBounds(20, 368, 100, 25);
		contentPane.add(lblNewLabel_8);
		
		name9 = new JTextField();
		name9.setColumns(10);
		name9.setBounds(160, 368, 200, 25);
		contentPane.add(name9);
		
		JLabel lblQuantity_8 = new JLabel("Quantity");
		lblQuantity_8.setBounds(370, 368, 80, 25);
		contentPane.add(lblQuantity_8);
		
		quantity9 = new JTextField();
		quantity9.setColumns(10);
		quantity9.setBounds(450, 368, 200, 25);
		contentPane.add(quantity9);
		
		JLabel lblNewLabel_9 = new JLabel("Medicine name");
		lblNewLabel_9.setBounds(20, 404, 100, 25);
		contentPane.add(lblNewLabel_9);
		
		name10 = new JTextField();
		name10.setColumns(10);
		name10.setBounds(160, 404, 200, 25);
		contentPane.add(name10);
		
		JLabel lblQuantity_9 = new JLabel("Quantity");
		lblQuantity_9.setBounds(370, 404, 80, 25);
		contentPane.add(lblQuantity_9);
		
		quantity10 = new JTextField();
		quantity10.setColumns(10);
		quantity10.setBounds(450, 404, 200, 25);
		contentPane.add(quantity10);
		
		JLabel lblNewLabel_10 = new JLabel("You gave wrong name. Please try again.");
		lblNewLabel_10.setVisible(false);
		lblNewLabel_10.setBounds(180, 500, 245, 25);
		contentPane.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Invalid quantity");
		lblNewLabel_11.setVisible(false);
		lblNewLabel_11.setBounds(270, 515, 100, 20);
		contentPane.add(lblNewLabel_11);
		
		JLabel lblNewLabel_9_1 = new JLabel("Customer name");
		lblNewLabel_9_1.setBounds(20, 440, 100, 25);
		contentPane.add(lblNewLabel_9_1);
		
		customer = new JTextField();
		customer.setColumns(10);
		customer.setBounds(160, 440, 200, 25);
		contentPane.add(customer);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean bool = false;
				double totalprice = 0;
				AllCustomer1 ac1 = new AllCustomer1(AllCustomer1.readcustomerfile());
				Customer c1 = ac1.searchcustomerByName(customer.getText());
				if (c1 != null) {
					if(customer.getText().equalsIgnoreCase(c1.getName())) {
						bool=true;
					}
				}
				
				try {
					try {
						Allmeds a1 = new Allmeds(Allmeds.readfile());
						Medicine[] meds = new Medicine[10];
						JTextField[] fields = {name1,name2,name3,name4,name5,name6,name7,name8,name9,name10};
						String[] names = new String[10];
						JTextField[] quantitities = {quantity1,quantity2,quantity3,quantity4,quantity5,quantity6,quantity7,quantity8,quantity9,quantity10};
						int[] quantities2 = {0,0,0,0,0,0,0,0,0,0};
						int counter = 0;
						for (int i=0;i<10;i++) {
							String name = fields[i].getText();
							//int quantity =;
							if (name.isEmpty()==false) {
								names[counter]=name;
								quantities2[counter]=Integer.parseInt(quantitities[i].getText());
								counter++;
							}
						}
						System.out.println("Counter"+counter);
						
						
						
						for(int i=0;i<counter;i++) {
							Medicine med = a1.searchmedicineByName(names[i]);
							if( med != null) {
								if (med.getQuantity()>=quantities2[i]) {
								meds[i]=med;
								totalprice = totalprice + quantities2[i]*med.getPrice();
								}
								else {
									NumberFormatException e2= new NumberFormatException();
									throw e2;
								}
							}	
							
							else {
								
								ManualException ex = new ManualException("Does not match");
								throw ex;
							}
						}
						Receitview r1 = new Receitview(Receit.this,meds,quantities2,bool,totalprice);
						r1.setVisible(true);
						Receit.this.setVisible(false);
					
					}
					catch(NumberFormatException e1) {
						lblNewLabel_11.setVisible(true);
					}
				}
				catch (ManualException e1) {
					lblNewLabel_10.setVisible(true);
				}
				
				//
				
				
			}
		});
		btnNewButton.setBounds(270, 540, 90, 25);
		contentPane.add(btnNewButton);
		
		
		
		
		
		
	}
}
