package Epharma.GUI;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.Medicine.*;
import Epharma.Customer.*;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Deletecustomer extends JFrame {

	private JPanel contentPane;
	private JTextField Field1;


	public Deletecustomer(Dashboard d1) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton Back = new JButton("Back");
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d1.setVisible(true);
				Deletecustomer.this.setVisible(false);
			}
		});
		Back.setBounds(0, 0, 120, 35);
		contentPane.add(Back);
		
		JLabel lblNewLabel = new JLabel("Customer name");
		lblNewLabel.setBounds(80, 190, 100, 30);
		contentPane.add(lblNewLabel);
		
		Field1 = new JTextField();
		Field1.setBounds(190, 190, 400, 30);
		contentPane.add(Field1);
		Field1.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Not found");
		lblNewLabel_1.setVisible(false);
		lblNewLabel_1.setBounds(280, 330, 100, 25);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Delete");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = Field1.getText();
				AllCustomer1 a1 = new AllCustomer1(AllCustomer1.readcustomerfile());
				Customer search = a1.searchcustomerByName(name);
				try {
					search.getName();
					a1.deletecustomerByName(name);;
					a1.addcustomerfile();
					d1.setVisible(true);
					Deletecustomer.this.setVisible(false);
					
					
				}
				catch (NullPointerException e1) {
					lblNewLabel_1.setVisible(true);
				}
			}
			
		});
		btnNewButton.setBounds(280, 250, 100, 30);
		contentPane.add(btnNewButton);
		

	}
}