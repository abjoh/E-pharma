package Epharma.GUI;



public class ManualException extends Exception {
	ManualException(String msg){
		super(msg);
	}
}
