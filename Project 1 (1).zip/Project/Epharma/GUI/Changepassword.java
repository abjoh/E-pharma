package Epharma.GUI;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.Medicine.*;
import Epharma.Customer.*;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;



import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Changepassword extends JFrame {

	private JPanel contentPane;
	private JTextField npassword;


	public Changepassword(Dashboard d1) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		npassword = new JTextField();
		npassword.setBounds(250, 350, 400, 30);
		contentPane.add(npassword);
		npassword.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("New password");
		lblNewLabel.setBounds(100, 350, 100, 30);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Change");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String password = npassword.getText();
				Readpassword pass=new Readpassword();
				pass.addpassfile(password + "\n");
				Changepassword.this.setVisible(false);
			}
		});
		btnNewButton.setBounds(300, 430, 100, 30);
		contentPane.add(btnNewButton);
		
		JButton Back = new JButton("Back");
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d1.setVisible(true);
				Changepassword.this.setVisible(false);
			}
		});
		Back.setBounds(0, 0, 120, 35);
		contentPane.add(Back);
	}
}
