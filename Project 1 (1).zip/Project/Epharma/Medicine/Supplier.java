package Epharma.Medicine;

import Epharma.Management.*;

public class Supplier {
	private String suppliername ;
	private String address ;
	private String phone ;

	
	public Supplier () {}
	public Supplier (String suppliername, String address, String phone){
		this.suppliername=suppliername;
		this.address=address;
		this.phone=phone;

	}
	

    public void set_Name(String suppliername){this.suppliername = suppliername;}
	public void set_Address(String address){this.address = address;}
	public void set_Phone(String phone){this.phone = phone;}

	public String get_Name(){return suppliername;}
	public String get_Address(){return address;}
	public String get_Phone(){return phone;}

	public void showsupplierdetails(){
		System.out.println("Suppplier name: " + suppliername);
		System.out.println("Address " + address);
		System.out.println("Company phone number " + phone);
	}
/*
	public void addsupplier(Supplier sup){
		for(int i = 0;i<Supplier.length;i++){
			if (listOfsupplier[i] == null){
				supplier[i] = sup;
				break;
			}
		}
	}

	public void deletesupplier(Supplier sup){
		for(int i = 0;i<supplier.length;i++){
			if (sup == supplier[i]){
				supplier[i] = null;
				break;
			}
		}
	}

	public void deletesupplierByName(String name){
		for(int i = 0;i<supplier.length;i++){
			if (name == supplier[i].get_personName()){
				supplier[i] = null;
				break;
			}
		}
	}	


	public static void main(String[] args) {
		Supplier s1 = new Supplier("ACI","Kuratoli Bazar","01971113065");
		Supplier s2 = new Supplier("MGI","Savar","01884616324");
		Supplier s3 = new Supplier("Square","Dhamrai","01884616324");
		s1.showsupplierdetails();
		

		Supplier supplieri2 = new Supplier();
		supplieri2.set_Name("Beximco");
		supplieri2.set_Address("Tongi");
		supplieri2.set_Phone("02-9810701");
		supplieri2.showsupplierdetails();
		
		Supplier suppliers[] = new Supplier[]{s1,s2,s3};
		Supplier supplieri1 = new Supplier("Alif","He is a Medicine Supplier","0123456");
		supplieri1.showsupplierdetails();
		
		Supplier supplieri21 = new Supplier();
		supplieri21.set_Name("Sakib");
		supplieri21.set_Address("He is a Medicine Supplier");
		supplieri21.set_Phone("0133567");


		
		
	}*/
}
