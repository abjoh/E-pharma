package Epharma.Medicine;

import Epharma.Management.*;


public class Allmeds{
	protected Medicine []listofmeds;
	//protected Medicine searchmed;

	public Allmeds(){}
	public Allmeds(Medicine []listofmeds){this.listofmeds = listofmeds;}

	public void set_listofmeds(Medicine []listofmeds){this.listofmeds = listofmeds;}

	public Medicine[] get_listofmeds(){return listofmeds;}
	public void addmedicinefile(){
		String info="";
		for(Medicine med : listofmeds){
			try {
			info= info +med.fileinfo();
			Filehandeling file = new Filehandeling();
			file.writeInFile(info,"Medicine.txt");
			}
			catch (NullPointerException e) {
				continue;
			}
		}
	}
	public static Medicine[] readfile(){
		Readmed file = new Readmed();
		return file.readFromFile("Medicine.txt");

	}
	public Medicine searchmedicineByName(String name){
		//below Medicine does not work
		Medicine searchmed=null;
		for(int i = 0;i<(listofmeds.length);i++){
			if (name.equals(listofmeds[i].get_medicinename())){
				searchmed = listofmeds[i];
			}
		}
		return searchmed;
	}

	public void addmedicine(Medicine med){
		for(int i = 0;i<listofmeds.length;i++){
			if (listofmeds[i] == null){
				listofmeds[i] = med;
				break;
			}
		}
	}

	public void deletemedicine(Medicine med){
		for(int i = 0;i<listofmeds.length;i++){
			if (med == listofmeds[i]){
				listofmeds[i] = null;
				break;
			}
		}
	}

	public void deletemedicineByName(String name){
		for(int i = 0;i<listofmeds.length;i++){
			if (name.equalsIgnoreCase(listofmeds[i].get_medicinename())){
				listofmeds[i] = null;
				break;
			}
		}
		
	}
	/*
	public void showmedInfo(){
		for(Medicine med : listofmeds){
			med.showmedicinedetails();
		}
	}

	public static void main(String[] args) {
		Medicine m1 = new Medicine("Napa","Paracitamol","25/05/2022","25/05/2024","Beximco", "Tongi", "02-9810701",25,100);
		m1.showmedicinedetails();
		Medicine m2 = new Medicine("sds","Paracitamol","25/05/2022","25/05/2024","Beximco", "Tongi", "02-9810701",25,100);
		m2.showmedicinedetails();
		Medicine m3 = new Medicine("asdsd","Paracitamol","25/05/2022","25/05/2024","Beximco", "Tongi", "02-9810701",25,100);
		m3.showmedicinedetails();
		Medicine m4 = new Medicine("asdasd","Paracitamol","25/05/2022","25/05/2024","Beximco", "Tongi", "02-9810701",25,100);
		m4.showmedicinedetails();

		Medicine []meds= {m1, m2};

		Allmeds allmed = new Allmeds(meds);
		System.out.println("Correction\n\n");
		allmed.deletemedicine(m1);
		allmed.addmedicine(m3);
		allmed.deletemedicineByName("sds");
		allmed.addmedicine(m4);

		
		//allmed.showmedInfo();
		Allmeds allmed= new Allmeds(Allmeds.readfile());
		allmed.deletemedicineByName("Tetracycline");
		//allmed.showmedInfo();
		allmed.addmedicinefile();

	}
			*/
}