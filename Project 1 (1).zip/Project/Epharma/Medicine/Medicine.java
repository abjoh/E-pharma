package Epharma.Medicine;

import Epharma.Management.*;

public class Medicine extends Supplier {
	private String medicinename;
	private String genericname;
	private String mgf;
	private String exp;
	private double price;
	private int quantity;
	
	
	public Medicine(){}
	public Medicine(String medicinename, String genericname, String mgf, String exp, String suppliername, String address, String phone,double price,int quantity){
		super(suppliername,address,phone);
		this.medicinename=medicinename;
		this.genericname=genericname;
		this.mgf=mgf;
		this.exp=exp;
		this.price=price;
		this.quantity=quantity;
		
	}

    public void set_medicinename(String medicinename){this.medicinename = medicinename;}
	public void set_genericname(String genericname){this.genericname = genericname;}
	public void set_mgf(String mgf){this.mgf = mgf;}
	public void set_exp(String exp){this.exp = exp;}

	public void setPrice(double price) {this.price = price;}

	public void setQuantity(int quantity) {this.quantity = quantity;}

	public String fileinfo(){
		String info = get_medicinename()+","+get_genericname()+","+get_mgf()+","+get_exp()+","+get_Name()+","+get_Address()+","+get_Phone()+ "," +getPrice()+"," + getQuantity() + "\n";
		return info;
	}
	public String get_medicinename(){return medicinename;}
	public String get_genericname(){return genericname;}
	public String get_mgf(){return mgf;}
	public String get_exp(){return exp;}
	public double getPrice() {return price;}
	public int getQuantity() {return quantity;}
/*
	public void showmedicinedetails(){
		System.out.println("Medicine Name :"+medicinename);
		System.out.println("Generic Name :"+genericname);
		System.out.println("MGF :"+mgf);
		System.out.println("EXP :"+exp);
		System.out.println("Price :"+price);
		System.out.println("Quntity :"+quantity);
		super.showsupplierdetails();
		System.out.println("");
	}

	

	public static void main(String[] args) {
		Medicine m1 = new Medicine("Napa","Paracitamol","25/05/2022","25/05/2024","Beximco", "Tongi", "02-9810701",25,100);
		m1.showmedicinedetails();
		
		Medicine medicine2 = new Medicine();
		medicine2.set_medicinename("Monas 10");
		medicine2.set_genericname("Cough");
		medicine2.set_mgf("20/08/2022");
		medicine2.set_exp("20/08/2025");
		medicine2.set_Name("Beximco");
		medicine2.set_Address("Tongi");
		medicine2.set_Phone("02-9810701");
		medicine2.setPrice(10);
		medicine2.setQuantity(100);
		medicine2.showmedicinedetails();

	}
	*/

}
