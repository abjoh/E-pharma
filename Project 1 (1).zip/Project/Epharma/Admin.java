package Epharma;

import Epharma.Staff.*;
import Epharma.Management.*;
import Epharma.GUI.*;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JLabel;

public class Admin extends JFrame {
	
	private JPanel contentPane;
	private JTextField txtId;
	private JButton Login;
	private JPasswordField passwordField;
	
	private String mainpassword;
	private JLabel lblNewLabel;
	
	public String getMainpassword() {
		return mainpassword;
	}

	public void setMainpassword(String mainpassword) {
		this.mainpassword = mainpassword;
	}

	public static String[] readstafffile(){
		Readpassword file = new Readpassword();
		return file.readFromFile("Password.txt");
	}

	public static void main(String[] args) {
		Admin admin = new Admin();
		admin.setVisible(true);
	}

	public Admin() {
		super("Admin");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(100, 100, 700, 700);
		
		contentPane = new JPanel();
		contentPane.setBackground(new Color(207, 235, 214));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtId = new JTextField();
		txtId.setText("ID");
		txtId.setToolTipText("ID");
		txtId.setBackground(new Color(207, 235, 214));
		txtId.setForeground(new Color(85, 111, 68));
		txtId.setBounds(250, 230, 200, 40);
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		lblNewLabel = new JLabel("Invalid user");
		lblNewLabel.setVisible(false);
		lblNewLabel.setBounds(300, 400, 100, 30);
		contentPane.add(lblNewLabel);
		
		Login = new JButton("Login");
		Login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = txtId.getText();
				String password=String.valueOf(passwordField.getPassword());
				System.out.println(id+password);
				AllStaff a1= new AllStaff(AllStaff.readstafffile());
				String name = a1.searchstaffByName(id).getName();
				System.out.println(name);
				Readpassword rp = new Readpassword();
				
				String[] passwords = rp.readFromFile("Password.txt");
				mainpassword = passwords[0];
				if (name.equals(name) && mainpassword.equals(password)) {
					System.out.println("True");
					Dashboard d1 = new Dashboard();
					d1.setVisible(true);
					//access admin JFrame
					Admin.this.setVisible(false);	
				}
				else {lblNewLabel.setVisible(true);}
			}
		});
		
				
		Login.setForeground(Color.BLACK);
		Login.setBounds(300, 360, 100, 30);
		contentPane.add(Login);
		
		passwordField = new JPasswordField();
		passwordField.setBackground(new Color(207, 235, 214));
		passwordField.setBounds(250, 300, 200, 40);
		contentPane.add(passwordField);
		

	}
	

}
