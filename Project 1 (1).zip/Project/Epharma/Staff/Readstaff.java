package Epharma.Staff;

import Epharma.Management.*;
import Epharma.Customer.*;

import java.io.*;
import java.lang.*;

public class Readstaff {
	private FileReader read;
    private BufferedReader buffer;
	public Staff[] readFromFile(String fname)
    {
		Staff []staffs = null;
		/*
			reading from a file genarates compile time exceptions (Checked Exceptions).
			So, we need to write the whole thing in try-catch.
		*/

        try
        {
            File file = new File(fname);
            read = new FileReader(file);			//creating the reader object to read from a file.
            buffer = new BufferedReader(read);		//creating the BufferedReader object using the reader object to read the file content.
            String fullText="", singleLine;					//declaring two string variables to store the content after reading.

            int counter = 0;
            while((singleLine=buffer.readLine())!=null){
                counter++;
            }


            staffs =new Staff[counter-1];
            int count=0;
            
            read = new FileReader(file);            //creating the reader object to read from a file.
            buffer = new BufferedReader(read);  
        
            
            while(count<(counter-1))		//reading one line from the file, storing it in the variable temp and checking whether it is null or not. It will be null at the end of reading from the file.
            {
                singleLine=buffer.readLine();
                String []linearray = singleLine.split(";");
               
                staffs[count]= new Staff(linearray[0],linearray[1],linearray[2],linearray[3],Integer.parseInt(linearray[4]),linearray[5],linearray[6],linearray[7],Integer.parseInt(linearray[8]));
                
                count++;
                
            }
           
            read.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
		return staffs;
    }
}

