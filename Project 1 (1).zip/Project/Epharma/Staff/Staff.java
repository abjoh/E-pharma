package Epharma.Staff;

import Epharma.Management.*;
import Epharma.Customer.*;

public class Staff extends Person{

	protected int salary;
	protected String dob, designation, id;

	public Staff(){
	}
	public Staff(String info, String name, String address, String phoneNumber, int age, String dob, String designation, String id, int salary){
		super(info, name, address, phoneNumber, age);
		this.dob = dob;
		this.designation = designation;
		this.id = id;
		this.salary = salary;
	}
	
	
	public void setDob(String dob){
		this.dob = dob;
	}
	
	public String getDob(){
		return dob;
	}
	
	public void setDesignation(String designation){
		this.designation = designation;
	}
	
	public String getDesignation(){
		return designation;
	}
	
	public void setId(String id){
		this.id = id;
	}
	
	public String getId(){
		return id;
	}
	
	public void setSalary(int salary){
		this.salary = salary;
	}
	
	public int getSalary(){
		return salary;
	}

	public String fileinfo(){
		String info =getInfo() +";"+ getName() +";"+ getAddress() +";"+ getPhoneNumber() +";"+ getAge() +";"+ getDob()+";"+getDesignation()+";"+getId()+";"+getSalary()+"\n";
		return info;
	}
/*
	public void showDetailsStaff(){
		super.showDetails();
		System.out.println("Date of Birth: "+ getDob());
		System.out.println("Designation: "+ getDesignation());
		System.out.println("ID: "+ getId());
		System.out.println("Salary: "+ getSalary());
	}
	
	public static void main(String[] args){
		
			protected int salary;
			protected String dob, designation, id;
		
		Staff e1 = new Staff("Employee", "Rahim", "Road #17, Nikunja - 2, Dhaka", "0174534****", 25, "24.01.1995", "Manager", "22039",  25000 );
		
		e1.showDetailsStaff();
		
		Staff e2 = new Staff();
		e2.setInfo("Employee");
		e2.setName("Karim");
		e2.setAddress("Road #17, Nikunja - 2, Dhaka");
		e2.setPhoneNumber("019*****8");
		e2.setAge(28);
		e2.setSalary(1500);
		e2.setDob("13.03.1996");
		e2.setId("22013");
		e2.setDesignation("Accountant");
		e2.showDetailsStaff();
	}
	*/
}