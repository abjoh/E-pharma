package Epharma.Staff;

import Epharma.Management.*;

public class AllStaff {

	protected Staff []listofstaff;
	//protected Person searchperson;

	public AllStaff(){}
	public AllStaff(Staff []listofstaff){
		this.listofstaff = listofstaff;

	}

	public void set_listofstaff(Staff []listofstaff){this.listofstaff = listofstaff;}

	public Staff[] get_listofstaff(){return listofstaff;}

	public void addstafffile(){
		String info="";
		for(Staff staff : listofstaff){
			try {
			info= info +staff.fileinfo();
			Filehandeling file = new Filehandeling();
			file.writeInFile(info,"Staff.txt");
			}
			catch (NullPointerException e) {
				continue;
			}
		}
	}
	public static Staff[] readstafffile(){
		Readstaff file = new Readstaff();
		return file.readFromFile("Staff.txt");
		

	}

	public Staff searchstaffByName(String name){
		//below person does not work
		Staff searchstaff = null;
		for(int i = 0;i<listofstaff.length;i++){
			if (name.equals(listofstaff[i].getName())){
				searchstaff = listofstaff[i];
			}
		}
		return searchstaff;
	}

	public void addstaff(Staff staff){
		for(int i = 0;i<listofstaff.length;i++){
			if (listofstaff[i] == null){
				listofstaff[i] = staff;
				break;
			}
		}
	}

	public void deletestaff(Staff staff){
		for(int i = 0;i<listofstaff.length;i++){
			if (staff == listofstaff[i]){
				listofstaff[i] = null;
				break;
			}
		}
	}

	public void deletestaffByName(String name){
		for(int i = 0;i<listofstaff.length;i++){
			if (name.equalsIgnoreCase(listofstaff[i].getName())){
				listofstaff[i] = null;
				break;
			}
		}
	}
	/*
	public void showstaffInfo(){
		for(Staff staff : listofstaff){
			staff.showDetails();
		}
	}

	public static void main(String[] args) {

		Customer c1 = new Customer("Customer", "Rahim", "Road #17, Nikunja - 2, Dhaka", "0174534****", 25, 0.07);
		
		c1.ShowDetailsOfCustomer();
		
		Customer c2 = new Customer();
		c2.setInfo("Customer");
		c2.setName("Karim");
		c2.setAddress("Road #17, Nikunja - 2, Dhaka");
		c2.setPhoneNumber("019*****8");
		c2.setAge(28);
		c2.setDiscount(0.07);
		c2.ShowDetailsOfCustomer();

		Staff e1 = new Staff("Employee", "Rahim", "Road #17, Nikunja - 2, Dhaka", "0174534****", 25, "24.01.1995", "Manager", "22039",  25000 );
		
		Staff e2 = new Staff();
		e2.setInfo("Employee");
		e2.setName("Karim");
		e2.setAddress("Road #17, Nikunja - 2, Dhaka");
		e2.setPhoneNumber("019*****8");
		e2.setAge(28);
		e2.setSalary(1500);
		e2.setDob("13.03.1996");
		e2.setId("22013");
		e2.setDesignation("Accountant");

		Staff []staff ={ e1, e2};
		//Customer []customer ={c1,c2};

		AllStaff staffs = new AllStaff(staff);
		staffs.addstafffile();
		AllStaff a2 = new AllStaff(AllStaff.readstafffile());
		a2.searchstaffByName("Rahim").showDetailsStaff();;
		

		
	}*/
}